const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_owner";
const SPOOF_UID = "spoof_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const pastTs = () => new Date(Date.now() - 2000);

function validQuotePayload(overrides = {}) {
  return {
    text: "من لم يذق مر التعلم ساعة تجرع ذل الجهل طول حياته",
    authorName: "الإمام الشافعي",
    topic: "حكمة",
    status: "pending",
    isOwnerQuote: false,
    isKnownAuthor: true,
    isVerified: false,
    authorImageUrl: "",
    sourceUrl: "https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D8%B4%D8%A7%D9%81%D8%B9%D9%8A",
    submittedByUid: ALICE_UID,
    submittedByName: "Alice",
    likesCount: 0,
    commentsCount: 0,
    createdAt: pastTs(),
    updatedAt: pastTs(),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write quotes", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("quotes").where("status", "==", "approved").get());
  await assertFails(unauthDb.collection("quotes").doc("q1").set(validQuotePayload()));
});

test("Visitor can submit a pending quote and read their own pending quote", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  await assertSucceeds(aliceDb.collection("quotes").doc("q_alice_1").set(validQuotePayload()));
  await assertSucceeds(aliceDb.collection("quotes").where("submittedByUid", "==", ALICE_UID).get());
});

test("Visitor cannot bypass moderation by setting status=approved or isOwnerQuote=true", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("quotes").doc("q_forged").set(validQuotePayload({ status: "approved" }))
  );
  await assertFails(
    aliceDb.collection("quotes").doc("q_forged2").set(validQuotePayload({ isOwnerQuote: true }))
  );
});

test("Shadow update with ghost field on quote is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("quotes").doc("q_shadow").set(validQuotePayload({ ghostFlag: true }))
  );
});

test("Another user cannot read Alice's pending quote or query unfiltered quotes", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_pending").set(validQuotePayload());
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("quotes").doc("q_pending").get());
  await assertFails(bobDb.collection("quotes").get());
});

test("Email spoofing test: unverified admin email is rejected from admin actions", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_pending").set(validQuotePayload());
  });

  const spoofDb = testEnv.authenticatedContext(SPOOF_UID, {
    email: "khaledhouatmi17@gmail.com",
    email_verified: false,
  }).firestore();

  await assertFails(spoofDb.collection("quotes").doc("q_pending").update({ status: "approved", updatedAt: pastTs() }));
});

test("Verified owner admin email can approve pending quote and add owner quote", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_pending").set(validQuotePayload());
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "khaledhouatmi17@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    adminDb.collection("quotes").doc("q_pending").update({
      status: "approved",
      isVerified: true,
      updatedAt: pastTs(),
    })
  );

  await assertSucceeds(
    adminDb.collection("quotes").doc("q_owner").set(
      validQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        isVerified: true,
        submittedByUid: ADMIN_UID,
        submittedByName: "أثر",
      })
    )
  );
});

test("Atomic like batch succeeds and non-atomic likesCount tampering fails", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_approved").set(
      validQuotePayload({ status: "approved", isVerified: true })
    );
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const quoteRef = bobDb.collection("quotes").doc("q_approved");
  const likeRef = quoteRef.collection("likes").doc(BOB_UID);

  // Non-atomic tamper without creating like doc must fail
  await assertFails(quoteRef.update({ likesCount: 1, updatedAt: pastTs() }));

  // Atomic batch creating like doc + incrementing likesCount must succeed
  const batch = bobDb.batch();
  batch.set(likeRef, { userId: BOB_UID, createdAt: pastTs() });
  batch.update(quoteRef, { likesCount: 1, updatedAt: pastTs() });
  await assertSucceeds(batch.commit());
});

test("Comments and reports enforce ownership and approved quote invariant", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_approved").set(
      validQuotePayload({ status: "approved", isVerified: true })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const commentRef = aliceDb.collection("quotes").doc("q_approved").collection("comments").doc("c1");

  await assertSucceeds(
    commentRef.set({
      quoteId: "q_approved",
      quoteStatus: "approved",
      userId: ALICE_UID,
      userName: "Alice",
      text: "اقتباس رائع ومؤثر",
      createdAt: pastTs(),
    })
  );

  // Bob cannot delete Alice's comment
  await assertFails(
    bobDb.collection("quotes").doc("q_approved").collection("comments").doc("c1").delete()
  );

  // Bob can report the quote, cannot read Alice's report
  await assertSucceeds(
    bobDb.collection("reports").doc("rep1").set({
      targetType: "quote",
      quoteId: "q_approved",
      targetPreview: "من لم يذق...",
      reason: "معلومات غير دقيقة",
      reporterUid: BOB_UID,
      reporterName: "Bob",
      status: "open",
      createdAt: pastTs(),
    })
  );
  await assertFails(aliceDb.collection("reports").doc("rep1").get());
});

test("User profiles and favorites are strictly isolated per user", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("quotes").doc("q_approved").set(
      validQuotePayload({ status: "approved", isVerified: true })
    );
  });

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      darkMode: false,
      createdAt: pastTs(),
      updatedAt: pastTs(),
    })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("favorites").doc("q_approved").set({
      quoteId: "q_approved",
      userId: ALICE_UID,
      createdAt: pastTs(),
    })
  );
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("favorites").get());
});
