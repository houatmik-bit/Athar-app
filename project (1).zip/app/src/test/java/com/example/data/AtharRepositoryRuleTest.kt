package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class AtharRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun submitVisitorQuote_authenticatedUser_createsPendingQuoteAndAppearsInMySubmissions() = runBlocking {
        val uid = signInTestUser("visitor_${UUID.randomUUID()}@test.com")
        val repository = AtharRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.submitVisitorQuote(
                text = "الكلمة الطيبة صدقة تترك أثراً لا يُنسى في القلوب.",
                authorName = "زائر كريم",
                topic = "حكمة",
                sourceUrl = ""
            )
        }
        assertTrue("Expected submitVisitorQuote success: ${result.exceptionOrNull()}", result.isSuccess)
        val quoteId = result.getOrThrow()

        val submissions = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMySubmissions(uid).first { list -> list.any { it.id == quoteId } }
        }
        val created = submissions.first { it.id == quoteId }
        assertEquals("pending", created.status)
        assertEquals(false, created.isOwnerQuote)
    }

    @Test
    fun createOwnerQuote_nonAdminUser_failsWithPermissionDenied() = runBlocking {
        signInTestUser("regular_${UUID.randomUUID()}@test.com")
        val repository = AtharRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createOwnerQuote(
                text = "محاولة نشر اقتباس معتمد دون صلاحية مالك.",
                authorName = "مستخدم",
                topic = "حكمة",
                isOwnerQuote = true,
                isKnownAuthor = false,
                isVerified = true,
                authorImageUrl = "",
                sourceUrl = ""
            )
        }
        assertTrue("Expected non-admin createOwnerQuote to fail", result.isFailure)
        val firestoreException = result.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }

    @Test
    fun observeApprovedQuotes_unauthenticatedUser_failsGracefully() = runBlocking {
        auth.signOut()
        val repository = AtharRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeApprovedQuotes().first()
            }
            fail("Expected unauthenticated observeApprovedQuotes to fail")
        } catch (e: Exception) {
            assertTrue(
                e is IllegalStateException ||
                    e.unwrapFirestoreException()?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
            )
        }
    }

    @Test
    fun observeUserFavorites_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser("alice_${UUID.randomUUID()}@test.com")
        signInTestUser("bob_${UUID.randomUUID()}@test.com")
        val bobRepo = AtharRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeUserFavorites(aliceUid).first()
            }
            fail("Expected cross-user favorites access to fail")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
