package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AtharRepository
import com.example.data.StarterQuotes
import com.example.data.unwrapFirestoreException
import com.example.model.Quote
import com.example.model.QuoteComment
import com.example.model.ReportItem
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T, val isStarterFallback: Boolean = false) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class AtharViewModel(
    private val repository: AtharRepository,
    private val currentUserId: String,
    val isAdmin: Boolean
) : ViewModel() {

    private val _selectedFilter = MutableStateFlow("الكل")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _featuredQuoteId = MutableStateFlow<String?>(null)

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    val quotesState: StateFlow<UiState<List<Quote>>> = repository.observeApprovedQuotes()
        .map<List<Quote>, UiState<List<Quote>>> { quotes ->
            if (quotes.isEmpty()) {
                UiState.Success(StarterQuotes.curatedQuotes, isStarterFallback = true)
            } else {
                UiState.Success(quotes, isStarterFallback = false)
            }
        }
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing quotes", rootError)
            emit(UiState.Error(rootError.message ?: "تعذر تحميل الاقتباسات"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val favoriteIds: StateFlow<Set<String>> = repository.observeUserFavorites(currentUserId)
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing favorites", firestoreError ?: error)
            emit(emptySet())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptySet()
        )

    val mySubmissions: StateFlow<List<Quote>> = repository.observeMySubmissions(currentUserId)
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing my submissions", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val pendingQuotes: StateFlow<List<Quote>> = (
        if (isAdmin) repository.observePendingQuotes() else flowOf(emptyList())
    )
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing pending quotes", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val openReports: StateFlow<List<ReportItem>> = (
        if (isAdmin) repository.observeOpenReports() else flowOf(emptyList())
    )
        .catch { error ->
            val firestoreError = error.unwrapFirestoreException()
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing reports", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val featuredQuote: StateFlow<Quote?> = combine(quotesState, _featuredQuoteId) { state, selectedId ->
        val list = (state as? UiState.Success)?.data.orEmpty()
        if (list.isEmpty()) {
            null
        } else {
            val found = selectedId?.let { id -> list.firstOrNull { it.id == id } }
            if (found != null) {
                found
            } else {
                val picked = list.random()
                _featuredQuoteId.value = picked.id
                picked
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = null
    )

    val filteredQuotes: StateFlow<UiState<List<Quote>>> = combine(
        quotesState,
        _selectedFilter,
        _searchQuery,
        favoriteIds
    ) { state, filter, query, favs ->
        when (state) {
            is UiState.Loading -> UiState.Loading
            is UiState.Error -> state
            is UiState.Success -> {
                val q = query.trim()
                val filtered = state.data.filter { quote ->
                    val matchesFilter = when (filter) {
                        "الكل" -> true
                        "اقتباساتي" -> quote.isOwnerQuote
                        "المفضلة" -> favs.contains(quote.id)
                        else -> quote.topic == filter
                    }
                    val matchesQuery = q.isEmpty() ||
                        quote.text.contains(q, ignoreCase = true) ||
                        quote.authorName.contains(q, ignoreCase = true) ||
                        quote.topic.contains(q, ignoreCase = true)
                    matchesFilter && matchesQuery
                }
                UiState.Success(filtered, state.isStarterFallback)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    fun syncUserOnLogin(user: FirebaseUser) {
        viewModelScope.launch {
            repository.syncUserProfile(user)
            if (isAdmin) {
                repository.seedStarterQuotesIfEmpty()
            }
        }
    }

    fun setFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun shuffleFeaturedQuote() {
        val list = (quotesState.value as? UiState.Success)?.data.orEmpty()
        if (list.size <= 1) return
        val currentId = _featuredQuoteId.value
        val candidates = list.filter { it.id != currentId }
        _featuredQuoteId.value = (if (candidates.isNotEmpty()) candidates else list).random().id
    }

    fun observeQuoteById(quoteId: String): Flow<Quote?> {
        val starter = StarterQuotes.curatedQuotes.firstOrNull { it.id == quoteId }
        return if (quoteId.startsWith("starter_") && (quotesState.value as? UiState.Success)?.isStarterFallback == true) {
            flowOf(starter)
        } else {
            repository.observeQuoteById(quoteId).map { it ?: starter }
        }
    }

    fun observeQuoteLiked(quoteId: String): Flow<Boolean> {
        return repository.observeQuoteLiked(quoteId, currentUserId)
            .catch { emit(false) }
    }

    fun observeComments(quoteId: String): Flow<List<QuoteComment>> {
        return repository.observeComments(quoteId)
            .catch { emit(emptyList()) }
    }

    fun toggleLike(quote: Quote, currentlyLiked: Boolean) {
        if (quote.id.startsWith("starter_") && (quotesState.value as? UiState.Success)?.isStarterFallback == true) {
            emitMessage("يرجى نشر الاقتباسات التأسيسية من لوحة تحكم المالك أولاً لتفعيل التفاعل.")
            return
        }
        viewModelScope.launch {
            repository.toggleLike(quote.id, currentlyLiked).onFailure {
                emitMessage("تعذر تحديث الإعجاب حالياً")
            }
        }
    }

    fun toggleFavorite(quoteId: String) {
        if (quoteId.startsWith("starter_") && (quotesState.value as? UiState.Success)?.isStarterFallback == true) {
            emitMessage("سيُتاح الحفظ بعد تهيئة الاقتباسات في قاعدة البيانات.")
            return
        }
        val currentlyFav = favoriteIds.value.contains(quoteId)
        viewModelScope.launch {
            repository.toggleFavorite(quoteId, currentlyFav)
                .onSuccess {
                    emitMessage(if (currentlyFav) "تمت الإزالة من المفضلة" else "تم الحفظ في المفضلة")
                }
                .onFailure {
                    emitMessage("تعذر تحديث المفضلة")
                }
        }
    }

    fun submitVisitorQuote(
        text: String,
        authorName: String,
        topic: String,
        sourceUrl: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.submitVisitorQuote(text, authorName, topic, sourceUrl)
                .onSuccess {
                    emitMessage("تم إرسال أثرك بنجاح وهو الآن قيد المراجعة")
                    onSuccess()
                }
                .onFailure {
                    emitMessage("تعذر إرسال الاقتباس، تحقق من البيانات وحاول مجدداً")
                }
        }
    }

    fun createOwnerQuote(
        text: String,
        authorName: String,
        topic: String,
        isOwnerQuote: Boolean,
        isKnownAuthor: Boolean,
        isVerified: Boolean,
        authorImageUrl: String,
        sourceUrl: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createOwnerQuote(
                text = text,
                authorName = authorName,
                topic = topic,
                isOwnerQuote = isOwnerQuote,
                isKnownAuthor = isKnownAuthor,
                isVerified = isVerified,
                authorImageUrl = authorImageUrl,
                sourceUrl = sourceUrl
            ).onSuccess {
                emitMessage("تم نشر الاقتباس في الرئيسية بنجاح")
                onSuccess()
            }.onFailure {
                emitMessage("تعذر نشر الاقتباس")
            }
        }
    }

    fun seedStarterQuotes() {
        viewModelScope.launch {
            repository.seedStarterQuotesIfEmpty()
                .onSuccess { count ->
                    if (count > 0) emitMessage("تمت إضافة $count اقتباساً تأسيسياً بنجاح")
                    else emitMessage("الاقتباسات موجودة مسبقاً")
                }
                .onFailure {
                    emitMessage("تعذر إضافة الاقتباسات التأسيسية")
                }
        }
    }

    fun approveQuote(
        quoteId: String,
        isKnownAuthor: Boolean,
        isVerified: Boolean,
        authorImageUrl: String,
        sourceUrl: String
    ) {
        viewModelScope.launch {
            repository.approveQuote(quoteId, isKnownAuthor, isVerified, authorImageUrl, sourceUrl)
                .onSuccess { emitMessage("تمت الموافقة على الاقتباس ونشره") }
                .onFailure { emitMessage("تعذر الموافقة على الاقتباس") }
        }
    }

    fun deleteQuote(quoteId: String) {
        viewModelScope.launch {
            repository.deleteQuote(quoteId)
                .onSuccess { emitMessage("تم حذف الاقتباس") }
                .onFailure { emitMessage("تعذر حذف الاقتباس") }
        }
    }

    fun addComment(quoteId: String, text: String, onSuccess: () -> Unit) {
        if (quoteId.startsWith("starter_") && (quotesState.value as? UiState.Success)?.isStarterFallback == true) {
            emitMessage("التعليقات متاحة بعد تهيئة الاقتباسات في قاعدة البيانات.")
            return
        }
        viewModelScope.launch {
            repository.addComment(quoteId, text)
                .onSuccess {
                    emitMessage("تمت إضافة تعليقك")
                    onSuccess()
                }
                .onFailure { emitMessage("تعذر إضافة التعليق") }
        }
    }

    fun deleteComment(quoteId: String, commentId: String) {
        viewModelScope.launch {
            repository.deleteComment(quoteId, commentId)
                .onSuccess { emitMessage("تم حذف التعليق") }
                .onFailure { emitMessage("تعذر حذف التعليق") }
        }
    }

    fun submitReport(
        targetType: String,
        quoteId: String,
        commentId: String?,
        targetPreview: String,
        reason: String
    ) {
        viewModelScope.launch {
            repository.submitReport(targetType, quoteId, commentId, targetPreview, reason)
                .onSuccess { emitMessage("شكراً لك، تم إرسال البلاغ للمراجعة") }
                .onFailure { emitMessage("تعذر إرسال البلاغ") }
        }
    }

    fun resolveReport(reportId: String) {
        viewModelScope.launch {
            repository.resolveReport(reportId)
                .onSuccess { emitMessage("تم إغلاق البلاغ") }
                .onFailure { emitMessage("تعذر تحديث حالة البلاغ") }
        }
    }

    fun showMessage(msg: String) = emitMessage(msg)

    private fun emitMessage(msg: String) {
        _snackbarMessages.tryEmit(msg)
    }

    private companion object {
        const val TAG = "AtharVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
