package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val AtharDarkColorScheme = darkColorScheme(
    primary = LuminousGoldPrimary,
    onPrimary = OnGoldDark,
    primaryContainer = GoldContainerDark,
    onPrimaryContainer = GoldOnContainerDark,
    secondary = RoseBurgundySecondary,
    onSecondary = Color(0xFF330C17),
    secondaryContainer = BurgundyContainerDark,
    onSecondaryContainer = BurgundyOnContainerDark,
    tertiary = EmeraldAccentDark,
    onTertiary = Color(0xFF0A2B22),
    background = ObsidianBackground,
    onBackground = CreamInkOnDark,
    surface = VelvetSurface,
    onSurface = CreamInkOnDark,
    surfaceVariant = RosewoodSurfaceVariant,
    onSurfaceVariant = MutedCreamOnDark,
    outline = VelvetOutline,
    error = Color(0xFFF2B8B5)
)

private val AtharLightColorScheme = lightColorScheme(
    primary = BurgundyPrimary,
    onPrimary = IvorySurface,
    primaryContainer = BurgundyLightContainer,
    onPrimaryContainer = BurgundyOnContainer,
    secondary = AntiqueGold,
    onSecondary = Color.White,
    secondaryContainer = GoldContainerLight,
    onSecondaryContainer = GoldOnContainerLight,
    tertiary = EmeraldAccent,
    onTertiary = Color.White,
    background = CreamBackground,
    onBackground = InkOnLight,
    surface = IvorySurface,
    onSurface = InkOnLight,
    surfaceVariant = SandSurfaceVariant,
    onSurfaceVariant = MutedInkOnLight,
    outline = ParchmentOutline,
    error = ErrorCrimson
)

val AtharShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun AtharTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AtharDarkColorScheme else AtharLightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = AtharShapes,
            content = content
        )
    }
}
