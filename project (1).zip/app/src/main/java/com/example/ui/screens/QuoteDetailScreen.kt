package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.QuoteComment
import com.example.ui.components.AdBannerPlaceholder
import com.example.ui.components.AuthorAvatar
import com.example.ui.components.ImageExportBottomSheet
import com.example.ui.components.ReportDialog
import com.example.ui.components.rememberResolvedAuthor
import com.example.ui.theme.AtharHeroQuoteTextStyle
import com.example.ui.theme.TopicColors
import com.example.ui.theme.VerifiedGreen
import com.example.ui.viewmodel.AtharViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteDetailScreen(
    quoteId: String,
    currentUserId: String,
    viewModel: AtharViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val quote by viewModel.observeQuoteById(quoteId).collectAsStateWithLifecycle(initialValue = null)
    val isLiked by viewModel.observeQuoteLiked(quoteId).collectAsStateWithLifecycle(initialValue = false)
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val comments by viewModel.observeComments(quoteId).collectAsStateWithLifecycle(initialValue = emptyList())

    var commentDraft by remember { mutableStateOf("") }
    var showImageExport by remember { mutableStateOf(false) }
    var reportQuote by remember { mutableStateOf(false) }
    var reportComment by remember { mutableStateOf<QuoteComment?>(null) }

    val canonicalUrl = "https://athar.app/quote/$quoteId"

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = quote?.let { "اقتباس • ${it.authorName}" } ?: "تفاصيل الاقتباس",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        val currentQuote = quote
        if (currentQuote == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
        val topicAccent = TopicColors.accentFor(currentQuote.topic, isDark)
        val resolvedAuthor = rememberResolvedAuthor(currentQuote)
        val seoTitle = "«${currentQuote.text.take(45)}${if (currentQuote.text.length > 45) "..." else ""}» — ${currentQuote.authorName} | أثر"
        val seoDescription = "اقرأ وشارك اقتباس ${currentQuote.authorName} في موضوع ${currentQuote.topic} على منصة أثر."

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item(key = "quote_hero") {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        border = BorderStroke(1.2.dp, topicAccent.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(22.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = TopicColors.containerFor(currentQuote.topic, isDark)
                                ) {
                                    Text(
                                        text = currentQuote.topic,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = topicAccent,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }

                                IconButton(onClick = { reportQuote = true }) {
                                    Icon(
                                        imageVector = Icons.Outlined.Flag,
                                        contentDescription = "إبلاغ عن الاقتباس",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "« ${currentQuote.text} »",
                                style = AtharHeroQuoteTextStyle,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AuthorAvatar(
                                    authorName = currentQuote.authorName,
                                    imageUrl = resolvedAuthor.imageUrl,
                                    sizeDp = 52
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = currentQuote.authorName,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        if (currentQuote.isVerifiedKnownAuthor || resolvedAuthor.imageUrl.isNotBlank()) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Rounded.Verified,
                                                contentDescription = "كاتب موثّق",
                                                tint = VerifiedGreen,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    if (currentQuote.isVerifiedKnownAuthor || resolvedAuthor.imageUrl.isNotBlank()) {
                                        Text(
                                            text = if (currentQuote.isVerifiedKnownAuthor) "كاتب معروف واقتباس موثّق" else "مفكر / كاتب معروف",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = VerifiedGreen
                                        )
                                    } else if (currentQuote.isOwnerQuote) {
                                        Text(
                                            text = "من مختارات صاحب أثر",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }

                            if (resolvedAuthor.sourceUrl.isNotBlank()) {
                                Spacer(modifier = Modifier.height(14.dp))
                                FilledTonalButton(
                                    onClick = {
                                        context.startActivity(
                                            Intent(Intent.ACTION_VIEW, Uri.parse(resolvedAuthor.sourceUrl))
                                        )
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("صفحة الكاتب على ويكيبيديا / المصدر الرسمي")
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.toggleLike(currentQuote, isLiked) },
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                                        contentDescription = "إعجاب",
                                        tint = if (isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("${currentQuote.likesCount}")
                                }

                                OutlinedButton(
                                    onClick = { viewModel.toggleFavorite(currentQuote.id) },
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    val isFav = favoriteIds.contains(currentQuote.id)
                                    Icon(
                                        imageVector = if (isFav) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                                        contentDescription = "المفضلة",
                                        tint = if (isFav) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isFav) "محفوظ" else "حفظ")
                                }

                                Button(
                                    onClick = { showImageExport = true },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("حمّل كصورة")
                                }
                            }
                        }
                    }
                }

                // Independent SEO Page Metadata & Shareable Link Card
                item(key = "seo_card") {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Link,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "الرابط المستقل وبيانات SEO",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("Athar Quote Link", canonicalUrl))
                                            viewModel.showMessage("تم نسخ رابط الاقتباس")
                                        }
                                    ) {
                                        Icon(Icons.Rounded.ContentCopy, contentDescription = "نسخ الرابط", modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "$seoTitle\n$canonicalUrl"
                                                )
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة رابط الاقتباس"))
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Share, contentDescription = "مشاركة الرابط", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                            Text(
                                text = seoTitle,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = seoDescription,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = canonicalUrl,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }

                item(key = "ad_slot_detail") {
                    AdBannerPlaceholder(slotTitle = "مساحة إعلانية • صفحة الاقتباس")
                }

                item(key = "comments_header") {
                    Text(
                        text = "التعليقات (${comments.size})",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item(key = "add_comment_box") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = commentDraft,
                            onValueChange = { commentDraft = it },
                            placeholder = { Text("أضف تعليقاً راقياً...") },
                            shape = RoundedCornerShape(16.dp),
                            maxLines = 3,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("comment_input")
                        )
                        Surface(
                            onClick = {
                                if (commentDraft.isNotBlank()) {
                                    val textToSend = commentDraft
                                    viewModel.addComment(quoteId, textToSend) {
                                        commentDraft = ""
                                    }
                                }
                            },
                            enabled = commentDraft.isNotBlank(),
                            shape = CircleShape,
                            color = if (commentDraft.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .size(50.dp)
                                .testTag("send_comment_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.Send,
                                    contentDescription = "إرسال التعليق",
                                    tint = if (commentDraft.isNotBlank()) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (comments.isEmpty()) {
                    item(key = "no_comments") {
                        Text(
                            text = "لا توجد تعليقات بعد. كن أول من يشارك انطباعه!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(items = comments, key = { it.id }) { comment ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        AuthorAvatar(
                                            authorName = comment.userName,
                                            imageUrl = comment.userPhotoUrl,
                                            sizeDp = 30
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = comment.userName,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Row {
                                        IconButton(
                                            onClick = { reportComment = comment },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Flag,
                                                contentDescription = "إبلاغ عن التعليق",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        if (comment.userId == currentUserId || viewModel.isAdmin) {
                                            IconButton(
                                                onClick = { viewModel.deleteComment(quoteId, comment.id) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.DeleteOutline,
                                                    contentDescription = "حذف التعليق",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(17.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = comment.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showImageExport) {
        quote?.let {
            ImageExportBottomSheet(
                quote = it,
                onDismiss = { showImageExport = false },
                onMessage = { msg -> viewModel.showMessage(msg) }
            )
        }
    }

    if (reportQuote) {
        quote?.let {
            ReportDialog(
                targetLabel = "الاقتباس",
                onDismiss = { reportQuote = false },
                onSubmit = { reason ->
                    viewModel.submitReport("quote", it.id, null, it.text, reason)
                    reportQuote = false
                }
            )
        }
    }

    reportComment?.let { c ->
        ReportDialog(
            targetLabel = "التعليق",
            onDismiss = { reportComment = null },
            onSubmit = { reason ->
                viewModel.submitReport("comment", c.quoteId, c.id, c.text, reason)
                reportComment = null
            }
        )
    }
}
