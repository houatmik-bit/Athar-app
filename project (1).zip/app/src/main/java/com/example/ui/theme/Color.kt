package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode — Warm Cream Parchment, Deep Burgundy, Teal & Gold
val CreamBackground = Color(0xFFFAF5EB)
val IvorySurface = Color(0xFFFFFDF8)
val SandSurfaceVariant = Color(0xFFF1E7D4)
val BurgundyPrimary = Color(0xFF6E1F32)
val BurgundyLightContainer = Color(0xFFF3D9DF)
val BurgundyOnContainer = Color(0xFF470E1D)
val AntiqueGold = Color(0xFFB88A2E)
val GoldContainerLight = Color(0xFFF6E9C9)
val GoldOnContainerLight = Color(0xFF4A3406)
val EmeraldAccent = Color(0xFF1F7A68)
val InkOnLight = Color(0xFF23191C)
val MutedInkOnLight = Color(0xFF6B595E)
val ParchmentOutline = Color(0xFFDCCEB8)

// Dark Mode — Obsidian Plum, Velvet Surface & Luminous Gold
val ObsidianBackground = Color(0xFF130F12)
val VelvetSurface = Color(0xFF1E171B)
val RosewoodSurfaceVariant = Color(0xFF2B2126)
val LuminousGoldPrimary = Color(0xFFD8B04C)
val OnGoldDark = Color(0xFF281D04)
val GoldContainerDark = Color(0xFF47350B)
val GoldOnContainerDark = Color(0xFFF7E4B0)
val RoseBurgundySecondary = Color(0xFFD96D86)
val BurgundyContainerDark = Color(0xFF4E1D29)
val BurgundyOnContainerDark = Color(0xFFF9D9DF)
val EmeraldAccentDark = Color(0xFF56D4B7)
val CreamInkOnDark = Color(0xFFF5EDE2)
val MutedCreamOnDark = Color(0xFFC5B6AF)
val VelvetOutline = Color(0xFF46373D)

val VerifiedGreen = Color(0xFF2E8B63)
val ErrorCrimson = Color(0xFFB3261E)

// Vibrant Modern Jewel-Tone Topic Palette
object TopicColors {
    fun accentFor(topic: String, isDark: Boolean): Color = when (topic) {
        "حكمة" -> if (isDark) Color(0xFF8C9EFF) else Color(0xFF3949AB) // Royal Indigo
        "حب" -> if (isDark) Color(0xFFFF7A9E) else Color(0xFFC22D58)   // Rose Crimson
        "نجاح" -> if (isDark) Color(0xFF4CE0B3) else Color(0xFF0E7C61) // Emerald Teal
        "صبر" -> if (isDark) Color(0xFFFFB74D) else Color(0xFFC47312)  // Warm Amber
        "أدب" -> if (isDark) Color(0xFFCE93D8) else Color(0xFF7B3FA0)  // Plum Violet
        "أمل" -> if (isDark) Color(0xFF64B5F6) else Color(0xFF1565C0)  // Sky Sapphire
        "حياة" -> if (isDark) Color(0xFFFF8A65) else Color(0xFFD14B2F) // Terracotta Coral
        else -> if (isDark) LuminousGoldPrimary else BurgundyPrimary
    }

    fun containerFor(topic: String, isDark: Boolean): Color =
        accentFor(topic, isDark).copy(alpha = if (isDark) 0.18f else 0.12f)
}
