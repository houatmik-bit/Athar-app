package com.example.ui.components

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.AuthorPortraitResolver
import com.example.data.AuthorWikiInfo
import com.example.model.AtharConstants
import com.example.model.Quote
import com.example.ui.theme.ArefRuqaaFontFamily
import com.example.ui.theme.AtharHeroQuoteTextStyle
import com.example.ui.theme.AtharQuoteTextStyle
import com.example.ui.theme.TopicColors
import com.example.ui.theme.VerifiedGreen
import com.example.util.CardThemeStyle
import com.example.util.QuoteImageExporter
import kotlinx.coroutines.launch

@Composable
fun rememberResolvedAuthor(quote: Quote): AuthorWikiInfo {
    var resolvedInfo by remember(quote.id, quote.authorName, quote.authorImageUrl, quote.sourceUrl) {
        mutableStateOf(
            AuthorWikiInfo(
                imageUrl = quote.authorImageUrl,
                sourceUrl = quote.sourceUrl
            )
        )
    }

    LaunchedEffect(quote.authorName, quote.authorImageUrl, quote.sourceUrl) {
        if (quote.authorImageUrl.isBlank() || quote.sourceUrl.isBlank()) {
            val fetched = AuthorPortraitResolver.resolveAuthor(quote.authorName)
            if (fetched != null) {
                resolvedInfo = AuthorWikiInfo(
                    imageUrl = quote.authorImageUrl.ifBlank { fetched.imageUrl },
                    sourceUrl = quote.sourceUrl.ifBlank { fetched.sourceUrl }
                )
            }
        }
    }

    return resolvedInfo
}

@Composable
fun AtharLogoMedallion(
    sizeDp: Int = 46,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = CircleShape,
        color = Color(0xFFFAF5EB),
        border = BorderStroke(
            1.5.dp,
            Brush.linearGradient(
                listOf(
                    Color(0xFFD8B04C),
                    Color(0xFF6E1F32),
                    Color(0xFF1F7A68)
                )
            )
        ),
        shadowElevation = 3.dp,
        modifier = modifier.size(sizeDp.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_athar_logo),
            contentDescription = "شعار أثر",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
        )
    }
}

@Composable
fun AtharTopBar(
    userName: String,
    userPhotoUrl: String?,
    isDarkTheme: Boolean,
    isAdmin: Boolean,
    onToggleTheme: () -> Unit,
    onSignOutClick: () -> Unit
) {
    var showAccountMenu by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 3.dp,
        shadowElevation = 3.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AtharLogoMedallion(sizeDp = 46)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "أثر",
                                fontFamily = ArefRuqaaFontFamily,
                                fontSize = 28.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (isAdmin) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = "المالك",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "كلماتٌ تبقى وأثرٌ يزهر",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            contentDescription = if (isDarkTheme) "الوضع الفاتح" else "الوضع الداكن",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Surface(
                        onClick = { showAccountMenu = true },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("account_button")
                    ) {
                        if (!userPhotoUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = userPhotoUrl,
                                contentDescription = "حساب $userName",
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = userName.take(1),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Subtle colorful accent hairline
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                Color(0xFFD8B04C),
                                Color(0xFF1F7A68).copy(alpha = 0.8f)
                            )
                        )
                    )
            )
        }
    }

    if (showAccountMenu) {
        AlertDialog(
            onDismissRequest = { showAccountMenu = false },
            title = {
                Text(
                    text = "أهلاً، $userName",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = if (isAdmin) {
                        "أنت مسجّل الدخول بصلاحية مالك المنصة."
                    } else {
                        "مسجّل الدخول بحساب Google. يمكنك حفظ مفضلتك ومشاركة أثرك."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showAccountMenu = false
                        onSignOutClick()
                    },
                    modifier = Modifier.testTag("sign_out_confirm_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تسجيل الخروج", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccountMenu = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
fun FeaturedRandomQuoteBanner(
    quote: Quote,
    isFavorited: Boolean,
    onShuffleClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onOpenDetail: () -> Unit
) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val topicAccent = TopicColors.accentFor(quote.topic, isDark)
    val resolvedAuthor = rememberResolvedAuthor(quote)

    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val glowStrength by animateFloatAsState(
        targetValue = if (isHovered || isPressed) 1f else 0.35f,
        animationSpec = tween(260),
        label = "heroGlow"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .hoverable(interactionSource)
            .drawBehind {
                val corner = 26.dp.toPx()
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(
                            topicAccent.copy(alpha = 0.24f * glowStrength),
                            Color(0xFFD8B04C).copy(alpha = 0.28f * glowStrength),
                            Color(0xFF1F7A68).copy(alpha = 0.20f * glowStrength)
                        )
                    ),
                    topLeft = Offset(-5.dp.toPx(), -4.dp.toPx()),
                    size = size.copy(
                        width = size.width + 10.dp.toPx(),
                        height = size.height + 8.dp.toPx()
                    ),
                    cornerRadius = CornerRadius(corner + 4.dp.toPx())
                )
            }
    ) {
        Card(
            onClick = onOpenDetail,
            interactionSource = interactionSource,
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isHovered) 8.dp else 4.dp),
            border = BorderStroke(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    listOf(
                        topicAccent.copy(alpha = 0.75f),
                        Color(0xFFD8B04C),
                        Color(0xFF1F7A68).copy(alpha = 0.7f)
                    )
                )
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("featured_quote_card")
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_ornament),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .matchParentSize()
                        .alpha(if (isDark) 0.10f else 0.16f)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    topicAccent.copy(alpha = 0.08f),
                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.07f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = topicAccent.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, topicAccent.copy(alpha = 0.35f))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AutoAwesome,
                                    contentDescription = null,
                                    tint = topicAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "اقتباس اليوم • اختيار عشوائي",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = topicAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row {
                            IconButton(
                                onClick = onFavoriteClick,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("featured_favorite_button")
                            ) {
                                Icon(
                                    imageVector = if (isFavorited) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                                    contentDescription = if (isFavorited) "إزالة من المفضلة" else "حفظ للمفضلة",
                                    tint = if (isFavorited) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = onShuffleClick,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("featured_shuffle_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Casino,
                                    contentDescription = "اقتباس عشوائي آخر",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "« ${quote.text} »",
                        style = AtharHeroQuoteTextStyle,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AuthorAvatar(
                                authorName = quote.authorName,
                                imageUrl = resolvedAuthor.imageUrl,
                                sizeDp = 40
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = quote.authorName,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (quote.isVerifiedKnownAuthor || resolvedAuthor.imageUrl.isNotBlank()) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Rounded.Verified,
                                            contentDescription = "كاتب معروف",
                                            tint = VerifiedGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = quote.topic,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = topicAccent
                                )
                            }
                        }

                        Text(
                            text = "اقرأ المزيد ←",
                            style = MaterialTheme.typography.labelMedium,
                            color = topicAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuoteCard(
    quote: Quote,
    isLiked: Boolean,
    isFavorited: Boolean,
    onCardClick: () -> Unit,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onShareClick: () -> Unit,
    onDownloadImageClick: () -> Unit,
    onReportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val topicAccent = TopicColors.accentFor(quote.topic, isDark)
    val topicContainer = TopicColors.containerFor(quote.topic, isDark)
    val resolvedAuthor = rememberResolvedAuthor(quote)

    // Smooth Fade-In + subtle slide entrance when a quote enters the list
    val enterAlpha = remember(quote.id) { Animatable(0f) }
    val enterOffsetY = remember(quote.id) { Animatable(24f) }
    LaunchedEffect(quote.id) {
        launch {
            enterAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing)
            )
        }
        launch {
            enterOffsetY.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
    }

    // Hover & Press Custom Glow Effect
    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val isGlowing = isHovered || isPressed

    val glowProgress by animateFloatAsState(
        targetValue = if (isGlowing) 1f else 0f,
        animationSpec = tween(durationMillis = 250, easing = FastOutSlowInEasing),
        label = "cardGlowProgress"
    )
    val hoverScale by animateFloatAsState(
        targetValue = if (isHovered) 1.014f else if (isPressed) 0.992f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "cardHoverScale"
    )

    val likeColor by animateColorAsState(
        targetValue = if (isLiked) Color(0xFFE03E65) else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "likeColor"
    )
    val likeScale by animateFloatAsState(
        targetValue = if (isLiked) 1.18f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "likeScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = enterAlpha.value
                translationY = enterOffsetY.value
                scaleX = hoverScale
                scaleY = hoverScale
            }
            .hoverable(interactionSource = interactionSource)
            .drawBehind {
                if (glowProgress > 0.01f) {
                    val corner = 24.dp.toPx()
                    val spread = 8.dp.toPx() * glowProgress
                    // Outer soft neon-gold & topic-colored halo
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(
                                topicAccent.copy(alpha = 0.28f * glowProgress),
                                Color(0xFFD8B04C).copy(alpha = 0.30f * glowProgress),
                                topicAccent.copy(alpha = 0.22f * glowProgress)
                            )
                        ),
                        topLeft = Offset(-spread, -spread),
                        size = size.copy(
                            width = size.width + spread * 2f,
                            height = size.height + spread * 2f
                        ),
                        cornerRadius = CornerRadius(corner + spread)
                    )
                    // Inner bright crisp glow ring
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(
                                topicAccent.copy(alpha = 0.65f * glowProgress),
                                Color(0xFFD8B04C).copy(alpha = 0.65f * glowProgress)
                            )
                        ),
                        cornerRadius = CornerRadius(22.dp.toPx()),
                        style = Stroke(width = 2.5.dp.toPx() * glowProgress)
                    )
                }
            }
    ) {
        Card(
            onClick = onCardClick,
            interactionSource = interactionSource,
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isGlowing) 8.dp else 2.dp),
            border = BorderStroke(
                width = if (isGlowing) 1.5.dp else 1.dp,
                color = if (isGlowing) topicAccent.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("quote_card_${quote.id}")
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Header badges row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = topicContainer,
                            border = BorderStroke(1.dp, topicAccent.copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = quote.topic,
                                style = MaterialTheme.typography.labelMedium,
                                color = topicAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp)
                            )
                        }
                        if (quote.isOwnerQuote) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "بقلم أثر",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onReportClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("report_quote_${quote.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Flag,
                            contentDescription = "إبلاغ عن الاقتباس",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quote Text in Amiri
                Text(
                    text = "« ${quote.text} »",
                    style = AtharQuoteTextStyle,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Author Row (auto-resolved portrait + Wikipedia link for known authors/thinkers)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        AuthorAvatar(
                            authorName = quote.authorName,
                            imageUrl = resolvedAuthor.imageUrl,
                            sizeDp = 42
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = quote.authorName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (quote.isVerifiedKnownAuthor || resolvedAuthor.imageUrl.isNotBlank()) {
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Icon(
                                        imageVector = Icons.Rounded.Verified,
                                        contentDescription = "اقتباس موثق",
                                        tint = VerifiedGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            if (quote.isVerifiedKnownAuthor || resolvedAuthor.imageUrl.isNotBlank()) {
                                Text(
                                    text = if (quote.isVerifiedKnownAuthor) "كاتب معروف • اقتباس موثّق" else "مفكر / كاتب معروف",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VerifiedGreen
                                )
                            }
                        }
                    }

                    if (resolvedAuthor.sourceUrl.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(resolvedAuthor.sourceUrl))
                                context.startActivity(intent)
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, topicAccent.copy(alpha = 0.6f)),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = "ويكيبيديا",
                                style = MaterialTheme.typography.labelSmall,
                                color = topicAccent
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                contentDescription = "فتح مصدر الكاتب",
                                tint = topicAccent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                Spacer(modifier = Modifier.height(6.dp))

                // Action Bar: Like, Comment, Favorite, Download Image, Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = onLikeClick,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("like_button_${quote.id}")
                        ) {
                            Icon(
                                imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "إعجاب",
                                tint = likeColor,
                                modifier = Modifier
                                    .size(20.dp)
                                    .scale(likeScale)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = quote.likesCount.toString(),
                                style = MaterialTheme.typography.labelLarge,
                                color = likeColor
                            )
                        }

                        TextButton(
                            onClick = onCommentClick,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("comment_button_${quote.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = "تعليقات",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = quote.commentsCount.toString(),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onDownloadImageClick,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("download_image_${quote.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Image,
                                contentDescription = "حمّل كصورة",
                                tint = topicAccent
                            )
                        }
                        IconButton(
                            onClick = onShareClick,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("share_quote_${quote.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = "مشاركة",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = onFavoriteClick,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("favorite_quote_${quote.id}")
                        ) {
                            Icon(
                                imageVector = if (isFavorited) Icons.Rounded.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = if (isFavorited) "محفوظ في المفضلة" else "حفظ للمفضلة",
                                tint = if (isFavorited) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthorAvatar(
    authorName: String,
    imageUrl: String,
    sizeDp: Int
) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.65f)),
        modifier = Modifier.size(sizeDp.dp)
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = "صورة $authorName",
                contentScale = ContentScale.Crop
            )
        } else {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = authorName.trim().take(1).ifEmpty { "أ" },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AdBannerPlaceholder(
    slotTitle: String = "مساحة إعلانية مخصصة",
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
        modifier = modifier
            .fillMaxWidth()
            .height(74.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = slotTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "مكان مهيأ لإعلانات الرعاة أو Google AdMob",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Text(
                    text = "إعلان",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ReportDialog(
    targetLabel: String,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var selectedReason by remember { mutableStateOf(AtharConstants.REPORT_REASONS.first()) }
    var customDetails by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "إبلاغ عن $targetLabel",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "اختر سبب البلاغ ليتم مراجعته من قِبل الإدارة:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                AtharConstants.REPORT_REASONS.forEach { reason ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedReason = reason }
                            .padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = selectedReason == reason,
                            onClick = { selectedReason = reason }
                        )
                        Text(
                            text = reason,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                if (selectedReason == "سبب آخر") {
                    OutlinedTextField(
                        value = customDetails,
                        onValueChange = { customDetails = it },
                        label = { Text("وضّح السبب") },
                        singleLine = false,
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalReason = if (selectedReason == "سبب آخر" && customDetails.isNotBlank()) {
                        customDetails.trim()
                    } else selectedReason
                    onSubmit(finalReason)
                }
            ) {
                Text("إرسال البلاغ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ImageExportBottomSheet(
    quote: Quote,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedStyle by remember { mutableStateOf(CardThemeStyle.CREAM) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }

    LaunchedEffect(quote.id, selectedStyle) {
        previewBitmap = QuoteImageExporter.renderQuoteBitmap(context, quote, selectedStyle)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "بطاقة الاقتباس للمشاركة",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "اختر الطابع التصميمي المناسب لانستغرام أو واتساب",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CardThemeStyle.entries.forEach { style ->
                    FilterChip(
                        selected = selectedStyle == style,
                        onClick = { selectedStyle = style },
                        label = { Text(style.labelAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val bmp = previewBitmap
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "معاينة بطاقة الاقتباس",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .height(270.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                )
            } else {
                Box(
                    modifier = Modifier.height(270.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val currentBmp = previewBitmap ?: return@OutlinedButton
                        isProcessing = true
                        scope.launch {
                            QuoteImageExporter.saveQuoteBitmapToGallery(context, currentBmp, quote.id)
                                .onSuccess { onMessage("تم حفظ البطاقة بنجاح في الصور") }
                                .onFailure { onMessage("تعذر حفظ الصورة") }
                            isProcessing = false
                        }
                    },
                    enabled = !isProcessing && previewBitmap != null,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_gallery_button")
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ كصورة")
                }

                Button(
                    onClick = {
                        val currentBmp = previewBitmap ?: return@Button
                        isProcessing = true
                        scope.launch {
                            QuoteImageExporter.shareQuoteCardImage(context, currentBmp, quote)
                                .onFailure { onMessage("تعذر فتح قائمة المشاركة") }
                            isProcessing = false
                        }
                    },
                    enabled = !isProcessing && previewBitmap != null,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("share_image_button")
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة الصورة")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
