package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AtharConstants
import com.example.model.Quote
import com.example.ui.components.AdBannerPlaceholder
import com.example.ui.components.FeaturedRandomQuoteBanner
import com.example.ui.components.ImageExportBottomSheet
import com.example.ui.components.QuoteCard
import com.example.ui.components.ReportDialog
import com.example.ui.theme.TopicColors
import com.example.ui.viewmodel.AtharViewModel
import com.example.ui.viewmodel.UiState

@Composable
fun HomeScreen(
    viewModel: AtharViewModel,
    onOpenQuoteDetail: (String) -> Unit
) {
    val context = LocalContext.current
    val quotesState by viewModel.filteredQuotes.collectAsStateWithLifecycle()
    val featuredQuote by viewModel.featuredQuote.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    var quoteForExport by remember { mutableStateOf<Quote?>(null) }
    var quoteForReport by remember { mutableStateOf<Quote?>(null) }

    val filterOptions = remember {
        listOf("الكل", "اقتباساتي", "المفضلة") + AtharConstants.TOPICS
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                // Colorful modern aurora wash at the top and corners
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFD8B04C).copy(alpha = if (isDark) 0.10f else 0.14f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.85f, size.height * 0.08f),
                        radius = size.width * 0.7f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF1F7A68).copy(alpha = if (isDark) 0.10f else 0.11f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.12f, size.height * 0.28f),
                        radius = size.width * 0.65f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFC22D58).copy(alpha = if (isDark) 0.07f else 0.08f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.8f, size.height * 0.72f),
                        radius = size.width * 0.6f
                    )
                )
            },
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            featuredQuote?.let { heroQuote ->
                item(key = "featured_hero") {
                    FeaturedRandomQuoteBanner(
                        quote = heroQuote,
                        isFavorited = favoriteIds.contains(heroQuote.id),
                        onShuffleClick = { viewModel.shuffleFeaturedQuote() },
                        onFavoriteClick = { viewModel.toggleFavorite(heroQuote.id) },
                        onOpenDetail = { onOpenQuoteDetail(heroQuote.id) }
                    )
                }
            }

            item(key = "search_bar") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("ابحث في الاقتباسات أو أسماء الكتّاب...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "بحث",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Rounded.Clear, contentDescription = "مسح البحث")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_quotes_input")
                )
            }

            item(key = "topic_filters") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filterOptions) { option ->
                        val isSelected = selectedFilter == option
                        val chipAccent = TopicColors.accentFor(option, isDark)
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setFilter(option) },
                            label = {
                                Text(
                                    text = option,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = chipAccent,
                                selectedLabelColor = if (isDark) Color(0xFF1A1215) else Color.White,
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier.testTag("filter_chip_$option")
                        )
                    }
                }
            }

            item(key = "ad_slot_top") {
                AdBannerPlaceholder(slotTitle = "مساحة إعلانية • الرئيسية")
            }

            when (val state = quotesState) {
                is UiState.Loading -> {
                    item(key = "loading") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }

                is UiState.Error -> {
                    item(key = "error") {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = state.message,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(24.dp)
                            )
                        }
                    }
                }

                is UiState.Success -> {
                    if (state.isStarterFallback) {
                        item(key = "starter_notice") {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "تُعرض باقة اقتباسات تأسيسية مختارة ريثما تتم مزامنة الإضافات الجديدة.",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    if (state.data.isEmpty()) {
                        item(key = "empty") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 42.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.BookmarkBorder,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "لا توجد اقتباسات مطابقة لهذا البحث أو التصنيف",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        itemsIndexed(
                            items = state.data,
                            key = { _, item -> item.id }
                        ) { index, quote ->
                            val isLiked by viewModel.observeQuoteLiked(quote.id)
                                .collectAsStateWithLifecycle(initialValue = false)

                            QuoteCard(
                                quote = quote,
                                isLiked = isLiked,
                                isFavorited = favoriteIds.contains(quote.id),
                                onCardClick = { onOpenQuoteDetail(quote.id) },
                                onLikeClick = { viewModel.toggleLike(quote, isLiked) },
                                onCommentClick = { onOpenQuoteDetail(quote.id) },
                                onFavoriteClick = { viewModel.toggleFavorite(quote.id) },
                                onShareClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "«${quote.text}»\n— ${quote.authorName}\nعبر تطبيق أثر\nhttps://athar.app/quote/${quote.id}"
                                        )
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الاقتباس"))
                                },
                                onDownloadImageClick = { quoteForExport = quote },
                                onReportClick = { quoteForReport = quote },
                                modifier = Modifier.animateItem()
                            )

                            if (index == 3) {
                                Spacer(modifier = Modifier.height(14.dp))
                                AdBannerPlaceholder(slotTitle = "مساحة إعلانية • بين الاقتباسات")
                            }
                        }
                    }
                }
            }

            item(key = "bottom_space") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    quoteForExport?.let { quote ->
        ImageExportBottomSheet(
            quote = quote,
            onDismiss = { quoteForExport = null },
            onMessage = { viewModel.showMessage(it) }
        )
    }

    quoteForReport?.let { quote ->
        ReportDialog(
            targetLabel = "الاقتباس",
            onDismiss = { quoteForReport = null },
            onSubmit = { reason ->
                viewModel.submitReport(
                    targetType = "quote",
                    quoteId = quote.id,
                    commentId = null,
                    targetPreview = quote.text,
                    reason = reason
                )
                quoteForReport = null
            }
        )
    }
}
