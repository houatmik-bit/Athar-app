package com.example.data

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class AuthorWikiInfo(
    val imageUrl: String,
    val sourceUrl: String
)

object AuthorPortraitResolver {
    private val cache = ConcurrentHashMap<String, AuthorWikiInfo>()
    private val negativeCache = ConcurrentHashMap.newKeySet<String>()

    private val nonPersonKeywords = setOf(
        "صاحب أثر", "مجهول", "غير معروف", "حكمة قديمة", "مثل عربي", "أثر", "قارئ أثر"
    )

    suspend fun resolveAuthor(authorName: String): AuthorWikiInfo? {
        val cleanName = authorName.trim()
        if (cleanName.length < 3 || nonPersonKeywords.any { cleanName.equals(it, ignoreCase = true) }) {
            return null
        }

        cache[cleanName]?.let { return it }
        if (negativeCache.contains(cleanName)) return null

        return withContext(Dispatchers.IO) {
            val result = fetchFromArabicSummary(cleanName)
                ?: fetchFromArabicSearch(cleanName)
                ?: fetchFromEnglishSearch(cleanName)

            if (result != null && result.imageUrl.isNotBlank()) {
                val safeImage = result.imageUrl.takeIf { isValidHttpUrl(it) }.orEmpty()
                val safeSource = result.sourceUrl.takeIf { isValidHttpUrl(it) }.orEmpty()
                if (safeImage.isNotBlank()) {
                    val info = AuthorWikiInfo(imageUrl = safeImage, sourceUrl = safeSource)
                    cache[cleanName] = info
                    return@withContext info
                }
            }
            negativeCache.add(cleanName)
            null
        }
    }

    private fun isValidHttpUrl(url: String): Boolean {
        return url.length <= 500 && (url.startsWith("https://") || url.startsWith("http://"))
    }

    private fun fetchFromArabicSummary(query: String): AuthorWikiInfo? {
        val encoded = Uri.encode(query.replace(" ", "_"))
        val json = httpGetJson("https://ar.wikipedia.org/api/rest_v1/page/summary/$encoded") ?: return null
        val thumb = json.optJSONObject("thumbnail")?.optString("source").orEmpty()
        val pageUrl = json.optJSONObject("content_urls")
            ?.optJSONObject("desktop")
            ?.optString("page")
            .orEmpty()
        return if (thumb.isNotBlank()) AuthorWikiInfo(thumb, pageUrl) else null
    }

    private fun fetchFromArabicSearch(query: String): AuthorWikiInfo? {
        return searchWikipedia("ar", query)
    }

    private fun fetchFromEnglishSearch(query: String): AuthorWikiInfo? {
        return searchWikipedia("en", query)
    }

    private fun searchWikipedia(lang: String, query: String): AuthorWikiInfo? {
        val encoded = Uri.encode(query)
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search" +
            "&gsrsearch=$encoded&gsrlimit=1&prop=pageimages|info&inprop=url&pithumbsize=400&format=json"
        val json = httpGetJson(url) ?: return null
        val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return null
        val keys = pages.keys()
        while (keys.hasNext()) {
            val pageObj = pages.optJSONObject(keys.next()) ?: continue
            val thumb = pageObj.optJSONObject("thumbnail")?.optString("source").orEmpty()
            val fullUrl = pageObj.optString("fullurl").orEmpty()
            if (thumb.isNotBlank()) {
                return AuthorWikiInfo(thumb, fullUrl)
            }
        }
        return null
    }

    private fun httpGetJson(urlString: String): JSONObject? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("User-Agent", "AtharQuotesAndroid/1.0 (https://athar.app)")
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                JSONObject(body)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
