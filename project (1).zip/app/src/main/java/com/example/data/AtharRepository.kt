package com.example.data

import android.content.Context
import com.example.R
import com.example.model.AtharConstants
import com.example.model.Quote
import com.example.model.QuoteComment
import com.example.model.ReportItem
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

object FirestoreProvider {
    @Volatile
    private var configured = false

    fun getDatabase(context: Context): FirebaseFirestore {
        val dbId = context.applicationContext.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        if (!configured) {
            synchronized(this) {
                if (!configured) {
                    try {
                        db.firestoreSettings = FirebaseFirestoreSettings.Builder()
                            .setLocalCacheSettings(
                                PersistentCacheSettings.newBuilder()
                                    .setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                                    .build()
                            )
                            .build()
                    } catch (_: IllegalStateException) {
                        // Firestore instance already started
                    }
                    configured = true
                }
            }
        }
        return db
    }
}

class AtharRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    constructor(context: Context) : this(FirestoreProvider.getDatabase(context))

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول بحساب Google أولاً.")
    }

    private fun requireUserName(): String {
        val user = auth.currentUser
        return user?.displayName?.takeIf { it.isNotBlank() }
            ?: user?.email?.substringBefore("@")?.takeIf { it.isNotBlank() }
            ?: "قارئ أثر"
    }

    fun isCurrentUserAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified && user.email.equals(AtharConstants.OWNER_EMAIL, ignoreCase = true)
    }

    fun observeApprovedQuotes(): Flow<List<Quote>> = flow {
        val uid = requireUserId()
        val path = "quotes"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", "approved")
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Quote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeQuoteById(quoteId: String): Flow<Quote?> = flow {
        val uid = requireUserId()
        val path = "quotes/$quoteId"
        emitAll(
            db.collection("quotes").document(quoteId)
                .snapshots()
                .map { doc ->
                    if (doc.exists()) {
                        doc.toObject(Quote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeMySubmissions(userId: String): Flow<List<Quote>> = flow {
        val path = "quotes"
        emitAll(
            db.collection(path)
                .whereEqualTo("submittedByUid", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Quote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePendingQuotes(): Flow<List<Quote>> = flow {
        val uid = requireUserId()
        val path = "quotes"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", "pending")
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Quote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeUserFavorites(userId: String): Flow<Set<String>> = flow {
        val path = "users/$userId/favorites"
        emitAll(
            db.collection("users").document(userId).collection("favorites")
                .snapshots()
                .map { snapshot -> snapshot.documents.map { it.id }.toSet() }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeQuoteLiked(quoteId: String, userId: String): Flow<Boolean> = flow {
        val path = "quotes/$quoteId/likes/$userId"
        emitAll(
            db.collection("quotes").document(quoteId)
                .collection("likes").document(userId)
                .snapshots()
                .map { doc -> doc.exists() }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeComments(quoteId: String): Flow<List<QuoteComment>> = flow {
        val uid = requireUserId()
        val path = "quotes/$quoteId/comments"
        emitAll(
            db.collection("quotes").document(quoteId).collection("comments")
                .whereEqualTo("quoteStatus", "approved")
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(QuoteComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeOpenReports(): Flow<List<ReportItem>> = flow {
        val uid = requireUserId()
        val path = "reports"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", "open")
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(ReportItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun syncUserProfile(user: FirebaseUser, darkMode: Boolean? = null) {
        val uid = user.uid
        val docRef = db.collection("users").document(uid)
        try {
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to (user.displayName?.takeIf { it.isNotBlank() } ?: "قارئ أثر"),
                    "email" to (user.email ?: ""),
                    "photoUrl" to (user.photoUrl?.toString() ?: ""),
                    "darkMode" to (darkMode ?: false),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else if (darkMode != null) {
                docRef.update(
                    mapOf(
                        "darkMode" to darkMode,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
        }
    }

    suspend fun submitVisitorQuote(
        text: String,
        authorName: String,
        topic: String,
        sourceUrl: String = ""
    ): Result<String> {
        val uid = requireUserId()
        val quoteId = UUID.randomUUID().toString()
        val docRef = db.collection("quotes").document(quoteId)
        val resolved = AuthorPortraitResolver.resolveAuthor(authorName)
        val finalImageUrl = resolved?.imageUrl.orEmpty()
        val finalSourceUrl = sourceUrl.trim().ifBlank { resolved?.sourceUrl.orEmpty() }
        val payload = mapOf(
            "text" to text.trim(),
            "authorName" to authorName.trim(),
            "topic" to topic,
            "status" to "pending",
            "isOwnerQuote" to false,
            "isKnownAuthor" to finalImageUrl.isNotBlank(),
            "isVerified" to false,
            "authorImageUrl" to finalImageUrl,
            "sourceUrl" to finalSourceUrl,
            "submittedByUid" to uid,
            "submittedByName" to requireUserName(),
            "likesCount" to 0L,
            "commentsCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(quoteId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun createOwnerQuote(
        text: String,
        authorName: String,
        topic: String,
        isOwnerQuote: Boolean,
        isKnownAuthor: Boolean,
        isVerified: Boolean,
        authorImageUrl: String,
        sourceUrl: String,
        customId: String? = null
    ): Result<String> {
        val uid = requireUserId()
        val quoteId = customId ?: UUID.randomUUID().toString()
        val docRef = db.collection("quotes").document(quoteId)
        val autoResolved = if (authorImageUrl.isBlank() || sourceUrl.isBlank()) {
            AuthorPortraitResolver.resolveAuthor(authorName)
        } else null
        val finalImage = authorImageUrl.trim().ifBlank { autoResolved?.imageUrl.orEmpty() }
        val finalSource = sourceUrl.trim().ifBlank { autoResolved?.sourceUrl.orEmpty() }
        val payload = mapOf(
            "text" to text.trim(),
            "authorName" to authorName.trim(),
            "topic" to topic,
            "status" to "approved",
            "isOwnerQuote" to isOwnerQuote,
            "isKnownAuthor" to (isKnownAuthor || finalImage.isNotBlank()),
            "isVerified" to isVerified,
            "authorImageUrl" to finalImage,
            "sourceUrl" to finalSource,
            "submittedByUid" to uid,
            "submittedByName" to requireUserName(),
            "likesCount" to 0L,
            "commentsCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(quoteId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun approveQuote(
        quoteId: String,
        isKnownAuthor: Boolean = false,
        isVerified: Boolean = false,
        authorImageUrl: String = "",
        sourceUrl: String = ""
    ): Result<Unit> {
        requireUserId()
        val docRef = db.collection("quotes").document(quoteId)
        return try {
            docRef.update(
                mapOf(
                    "status" to "approved",
                    "isKnownAuthor" to isKnownAuthor,
                    "isVerified" to isVerified,
                    "authorImageUrl" to authorImageUrl.trim(),
                    "sourceUrl" to sourceUrl.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteQuote(quoteId: String): Result<Unit> {
        requireUserId()
        val docRef = db.collection("quotes").document(quoteId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleLike(quoteId: String, currentlyLiked: Boolean): Result<Unit> {
        val uid = requireUserId()
        val quoteRef = db.collection("quotes").document(quoteId)
        val likeRef = quoteRef.collection("likes").document(uid)
        return try {
            val batch = db.batch()
            if (currentlyLiked) {
                batch.delete(likeRef)
                batch.update(
                    quoteRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    likeRef,
                    mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    quoteRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, quoteRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(quoteId: String, currentlyFavorited: Boolean): Result<Unit> {
        val uid = requireUserId()
        val favRef = db.collection("users").document(uid).collection("favorites").document(quoteId)
        return try {
            if (currentlyFavorited) {
                favRef.delete().await()
            } else {
                favRef.set(
                    mapOf(
                        "quoteId" to quoteId,
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, favRef.path)
            Result.failure(e)
        }
    }

    suspend fun addComment(quoteId: String, text: String): Result<String> {
        val uid = requireUserId()
        val commentId = UUID.randomUUID().toString()
        val quoteRef = db.collection("quotes").document(quoteId)
        val commentRef = quoteRef.collection("comments").document(commentId)
        val photoUrl = auth.currentUser?.photoUrl?.toString() ?: ""
        return try {
            val batch = db.batch()
            batch.set(
                commentRef,
                mapOf(
                    "quoteId" to quoteId,
                    "quoteStatus" to "approved",
                    "userId" to uid,
                    "userName" to requireUserName(),
                    "userPhotoUrl" to photoUrl,
                    "text" to text.trim(),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                quoteRef,
                mapOf(
                    "commentsCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(commentId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteComment(quoteId: String, commentId: String): Result<Unit> {
        requireUserId()
        val quoteRef = db.collection("quotes").document(quoteId)
        val commentRef = quoteRef.collection("comments").document(commentId)
        return try {
            val batch = db.batch()
            batch.delete(commentRef)
            batch.update(
                quoteRef,
                mapOf(
                    "commentsCount" to FieldValue.increment(-1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, commentRef.path)
            Result.failure(e)
        }
    }

    suspend fun submitReport(
        targetType: String,
        quoteId: String,
        commentId: String?,
        targetPreview: String,
        reason: String
    ): Result<String> {
        val uid = requireUserId()
        val reportId = UUID.randomUUID().toString()
        val docRef = db.collection("reports").document(reportId)
        val payload = buildMap {
            put("targetType", targetType)
            put("quoteId", quoteId)
            if (!commentId.isNullOrBlank()) {
                put("commentId", commentId)
            }
            put("targetPreview", targetPreview.take(280))
            put("reason", reason.trim().take(200))
            put("reporterUid", uid)
            put("reporterName", requireUserName())
            put("status", "open")
            put("createdAt", FieldValue.serverTimestamp())
        }
        return try {
            docRef.set(payload).await()
            Result.success(reportId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun resolveReport(reportId: String): Result<Unit> {
        requireUserId()
        val docRef = db.collection("reports").document(reportId)
        return try {
            docRef.update(mapOf("status" to "resolved")).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun seedStarterQuotesIfEmpty(): Result<Int> {
        if (!isCurrentUserAdmin()) return Result.success(0)
        return try {
            val existing = db.collection("quotes").whereEqualTo("status", "approved").limit(1).get().await()
            if (!existing.isEmpty) return Result.success(0)
            var count = 0
            for (q in StarterQuotes.curatedQuotes) {
                createOwnerQuote(
                    text = q.text,
                    authorName = q.authorName,
                    topic = q.topic,
                    isOwnerQuote = q.isOwnerQuote,
                    isKnownAuthor = q.isKnownAuthor,
                    isVerified = q.isVerified,
                    authorImageUrl = q.authorImageUrl,
                    sourceUrl = q.sourceUrl,
                    customId = q.id
                ).onSuccess { count++ }
            }
            Result.success(count)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "quotes")
            Result.failure(e)
        }
    }
}
