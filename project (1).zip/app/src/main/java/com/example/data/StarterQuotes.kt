package com.example.data

import com.example.model.Quote

object StarterQuotes {
    val curatedQuotes: List<Quote> = listOf(
        Quote(
            id = "starter_owner_1",
            text = "الأثر الجميل لا يموت بغياب صاحبه، بل يبقى كالعطر في ثنايا الذاكرة يوقظ الأمل كلما مرّت به الأيام.",
            authorName = "صاحب أثر",
            topic = "أمل",
            status = "approved",
            isOwnerQuote = true,
            isKnownAuthor = false,
            isVerified = true,
            authorImageUrl = "",
            sourceUrl = "",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_owner_2",
            text = "اختر كلماتك كما تختار البذور؛ فما تزرعه اليوم في قلوب الناس ستجني ثماره سلاماً ووفاءً في غدك.",
            authorName = "صاحب أثر",
            topic = "حكمة",
            status = "approved",
            isOwnerQuote = true,
            isKnownAuthor = false,
            isVerified = true,
            authorImageUrl = "",
            sourceUrl = "",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_owner_3",
            text = "الصبر ليس انتظاراً عاجزاً، بل هو ثقة هادئة بأنّ ما كتبه الله لك سيزهر في أوانه الأجمل.",
            authorName = "صاحب أثر",
            topic = "صبر",
            status = "approved",
            isOwnerQuote = true,
            isKnownAuthor = false,
            isVerified = true,
            authorImageUrl = "",
            sourceUrl = "",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_mutanabbi",
            text = "عَلى قَدرِ أَهلِ العَزمِ تَأتي العَزائِمُ، وَتَأتي عَلى قَدرِ الكِرامِ المَكارِمُ.",
            authorName = "أبو الطيب المتنبي",
            topic = "نجاح",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Al-Mutanabbi.jpg/440px-Al-Mutanabbi.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D8%A3%D8%A8%D9%88_%D8%A7%D9%84%D8%B7%D9%8A%D8%A8_%D8%A7%D9%84%D9%85%D8%AA%D9%86%D8%A8%D9%8A",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_gibran",
            text = "الجمال ليس في الوجه، إنما الجمال نورٌ يشعّ من القلب.",
            authorName = "جبران خليل جبران",
            topic = "أدب",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/87/Kahlil_Gibran_1913.jpg/440px-Kahlil_Gibran_1913.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D8%AC%D8%A8%D8%B1%D8%A7%D9%86_%D8%AE%D9%84%D9%8A%D9%84_%D8%AC%D8%A8%D8%B1%D8%A7%D9%86",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_darwish",
            text = "على هذه الأرض ما يستحقّ الحياة: تردّد إبريل، رائحة الخبز في الفجر، وبدايات الحبّ.",
            authorName = "محمود درويش",
            topic = "حياة",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/Mahmoud_Darwish_portrait.jpg/440px-Mahmoud_Darwish_portrait.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D9%85%D8%AD%D9%85%D9%88%D8%AF_%D8%AF%D8%B1%D9%88%D9%8A%D8%B4",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_shawqi",
            text = "وَإِنَّما الأُمَمُ الأَخلاقُ ما بَقِيَت، فَإِن هُمُ ذَهَبَت أَخلاقُهُم ذَهَبوا.",
            authorName = "أحمد شوقي",
            topic = "حكمة",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Ahmed_Shawqi.jpg/440px-Ahmed_Shawqi.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D8%A3%D8%AD%D9%85%D8%AF_%D8%B4%D9%88%D9%82%D9%8A",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_rumi",
            text = "ما تبحث عنه في هذا العالم، يبحث عنك أيضاً.",
            authorName = "جلال الدين الرومي",
            topic = "حب",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Mevlana_statue_in_Konya.jpg/440px-Mevlana_statue_in_Konya.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D8%AC%D9%84%D8%A7%D9%84_%D8%A7%D9%84%D8%AF%D9%8A%D9%86_%D8%A7%D9%84%D8%B1%D9%88%D9%85%D9%8A",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_mahfouz",
            text = "النجاح الحقيقي لا يُقاس بما نبلغه من مناصب، بل بما نتخطاه من عقبات ونتركه من قيمة.",
            authorName = "نجيب محفوظ",
            topic = "نجاح",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Naguib_Mahfouz.jpg/440px-Naguib_Mahfouz.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D9%86%D8%AC%D9%8A%D8%A8_%D9%85%D8%AD%D9%81%D9%88%D8%B8",
            submittedByName = "أثر"
        ),
        Quote(
            id = "starter_abumadi",
            text = "أيّهذا الشاكي وما بك داءٌ، كن جميلاً ترَ الوجودَ جميلا.",
            authorName = "إيليا أبو ماضي",
            topic = "أمل",
            status = "approved",
            isOwnerQuote = false,
            isKnownAuthor = true,
            isVerified = true,
            authorImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Elia_Abu_Madi.jpg/440px-Elia_Abu_Madi.jpg",
            sourceUrl = "https://ar.wikipedia.org/wiki/%D8%A5%D9%8A%D9%84%D9%8A%D8%A7_%D8%A3%D8%A8%D9%88_%D9%85%D8%A7%D8%B6%D9%8A",
            submittedByName = "أثر"
        )
    )
}
