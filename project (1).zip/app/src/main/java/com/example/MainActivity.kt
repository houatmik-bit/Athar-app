package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.auth.GoogleAuthHelper
import com.example.data.AtharRepository
import com.example.data.FirestoreProvider
import com.example.data.ThemePreferenceStore
import com.example.model.AtharConstants
import com.example.ui.components.AtharTopBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaveYourMarkScreen
import com.example.ui.screens.QuoteDetailScreen
import com.example.ui.theme.AtharTheme
import com.example.ui.viewmodel.AtharViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private object AtharRoutes {
    const val HOME = "home"
    const val LEAVE_MARK = "leave_mark"
    const val ADMIN = "admin"
    const val QUOTE_DETAIL = "quote/{quoteId}"
    fun quoteDetail(quoteId: String) = "quote/$quoteId"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDeepLinkQuoteId = extractQuoteIdFromIntent(intent)

        setContent {
            val context = LocalContext.current
            val themeStore = remember(context) { ThemePreferenceStore(context.applicationContext) }
            val storedDark by themeStore.isDarkMode.collectAsStateWithLifecycle(initialValue = null)
            val systemDark = isSystemInDarkTheme()
            val isDarkTheme = storedDark ?: systemDark
            val scope = rememberCoroutineScope()

            AtharTheme(darkTheme = isDarkTheme) {
                AppNavigation(
                    isDarkTheme = isDarkTheme,
                    initialDeepLinkQuoteId = initialDeepLinkQuoteId,
                    onToggleTheme = {
                        scope.launch {
                            themeStore.setDarkMode(!isDarkTheme)
                        }
                    }
                )
            }
        }
    }

    private fun extractQuoteIdFromIntent(intent: Intent?): String? {
        val data = intent?.data ?: return null
        return when (data.scheme) {
            "athar" -> data.lastPathSegment
            "https" -> if (data.pathSegments.firstOrNull() == "quote") data.pathSegments.getOrNull(1) else null
            else -> null
        }
    }
}

@Composable
private fun AppNavigation(
    isDarkTheme: Boolean,
    initialDeepLinkQuoteId: String?,
    onToggleTheme: () -> Unit
) {
    val auth = remember { Firebase.auth }
    var currentUser by remember { mutableStateOf(auth.currentUser) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            isDarkTheme = isDarkTheme,
            onToggleTheme = onToggleTheme,
            onAuthSuccess = { currentUser = auth.currentUser }
        )
    } else {
        key(user.uid) {
            AuthenticatedAtharShell(
                user = user,
                isDarkTheme = isDarkTheme,
                initialDeepLinkQuoteId = initialDeepLinkQuoteId,
                onToggleTheme = onToggleTheme
            )
        }
    }
}

@Composable
private fun AuthenticatedAtharShell(
    user: FirebaseUser,
    isDarkTheme: Boolean,
    initialDeepLinkQuoteId: String?,
    onToggleTheme: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val isAdmin = remember(user.uid, user.email, user.isEmailVerified) {
        user.isEmailVerified && user.email.equals(AtharConstants.OWNER_EMAIL, ignoreCase = true)
    }

    val viewModel: AtharViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val db = FirestoreProvider.getDatabase(app)
                AtharViewModel(
                    repository = AtharRepository(db),
                    currentUserId = user.uid,
                    isAdmin = isAdmin
                )
            }
        }
    )

    LaunchedEffect(user.uid) {
        viewModel.syncUserOnLogin(user)
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val isDetailRoute = currentRoute?.startsWith("quote/") == true

    LaunchedEffect(initialDeepLinkQuoteId) {
        if (!initialDeepLinkQuoteId.isNullOrBlank()) {
            navController.navigate(AtharRoutes.quoteDetail(initialDeepLinkQuoteId))
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val pendingQuotes by viewModel.pendingQuotes.collectAsStateWithLifecycle()
    val openReports by viewModel.openReports.collectAsStateWithLifecycle()
    val adminBadgeCount = pendingQuotes.size + openReports.size

    val navItems = remember(isAdmin) {
        buildList {
            add(Triple(AtharRoutes.HOME, "الرئيسية", Icons.Rounded.AutoStories))
            add(Triple(AtharRoutes.LEAVE_MARK, "اترك أثرك", Icons.Rounded.EditNote))
            if (isAdmin) {
                add(Triple(AtharRoutes.ADMIN, "لوحة التحكم", Icons.Rounded.Shield))
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (!isDetailRoute) {
                    Column(modifier = Modifier.statusBarsPadding()) {
                        AtharTopBar(
                            userName = user.displayName?.takeIf { it.isNotBlank() } ?: "قارئ أثر",
                            userPhotoUrl = user.photoUrl?.toString(),
                            isDarkTheme = isDarkTheme,
                            isAdmin = isAdmin,
                            onToggleTheme = onToggleTheme,
                            onSignOutClick = {
                                GoogleAuthHelper.signOut(credentialManager, scope)
                            }
                        )
                    }
                }
            },
            bottomBar = {
                if (!useNavRail && !isDetailRoute) {
                    NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                        navItems.forEach { (route, label, icon) ->
                            val selected = currentRoute == route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(route) {
                                        popUpTo(AtharRoutes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    if (route == AtharRoutes.ADMIN && adminBadgeCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$adminBadgeCount") } }) {
                                            Icon(icon, contentDescription = label)
                                        }
                                    } else {
                                        Icon(icon, contentDescription = label)
                                    }
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail && !isDetailRoute) {
                    NavigationRail {
                        navItems.forEach { (route, label, icon) ->
                            val selected = currentRoute == route
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(route) {
                                        popUpTo(AtharRoutes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    if (route == AtharRoutes.ADMIN && adminBadgeCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$adminBadgeCount") } }) {
                                            Icon(icon, contentDescription = label)
                                        }
                                    } else {
                                        Icon(icon, contentDescription = label)
                                    }
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AtharRoutes.HOME,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(AtharRoutes.HOME) {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenQuoteDetail = { quoteId ->
                                navController.navigate(AtharRoutes.quoteDetail(quoteId))
                            }
                        )
                    }
                    composable(AtharRoutes.LEAVE_MARK) {
                        LeaveYourMarkScreen(viewModel = viewModel)
                    }
                    composable(AtharRoutes.ADMIN) {
                        AdminDashboardScreen(viewModel = viewModel)
                    }
                    composable(
                        route = AtharRoutes.QUOTE_DETAIL,
                        arguments = listOf(navArgument("quoteId") { type = NavType.StringType }),
                        deepLinks = listOf(
                            navDeepLink { uriPattern = "athar://quote/{quoteId}" },
                            navDeepLink { uriPattern = "https://athar.app/quote/{quoteId}" }
                        )
                    ) { entry ->
                        val quoteId = entry.arguments?.getString("quoteId").orEmpty()
                        QuoteDetailScreen(
                            quoteId = quoteId,
                            currentUserId = user.uid,
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
