package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.model.Quote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class CardThemeStyle(val labelAr: String) {
    CREAM("ورق كريمي"),
    DARK("ليلي فاخر"),
    BURGUNDY("عنابي ملكي"),
    TEAL_AURORA("زمردي مشرق")
}

object QuoteImageExporter {

    suspend fun renderQuoteBitmap(
        context: Context,
        quote: Quote,
        style: CardThemeStyle
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val (bgTop, bgBottom, accentColor, textColor, secondaryTextColor, borderColor) = when (style) {
            CardThemeStyle.CREAM -> CardColors(
                bgTop = 0xFFFAF5EB.toInt(),
                bgBottom = 0xFFF2E6D2.toInt(),
                accent = 0xFF6E1F32.toInt(),
                text = 0xFF23191C.toInt(),
                secondary = 0xFF6B595E.toInt(),
                border = 0xFFB88A2E.toInt()
            )
            CardThemeStyle.DARK -> CardColors(
                bgTop = 0xFF1A1417.toInt(),
                bgBottom = 0xFF100C0E.toInt(),
                accent = 0xFFD8B04C.toInt(),
                text = 0xFFF5EDE2.toInt(),
                secondary = 0xFFC5B6AF.toInt(),
                border = 0xFFD8B04C.toInt()
            )
            CardThemeStyle.BURGUNDY -> CardColors(
                bgTop = 0xFF4F1624.toInt(),
                bgBottom = 0xFF2B0B13.toInt(),
                accent = 0xFFE6C267.toInt(),
                text = 0xFFFAF3E6.toInt(),
                secondary = 0xFFE2C9CE.toInt(),
                border = 0xFFE6C267.toInt()
            )
            CardThemeStyle.TEAL_AURORA -> CardColors(
                bgTop = 0xFF144E46.toInt(),
                bgBottom = 0xFF1B2B4B.toInt(),
                accent = 0xFFF4D06F.toInt(),
                text = 0xFFFAF7F0.toInt(),
                secondary = 0xFFC5E3DC.toInt(),
                border = 0xFFF4D06F.toInt()
            )
        }

        // Background gradient
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                bgTop, bgBottom, Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Outer ornamental frame
        val outerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = borderColor
            this.style = Paint.Style.STROKE
            this.strokeWidth = 3f
            this.alpha = 140
        }
        canvas.drawRoundRect(RectF(56f, 56f, width - 56f, height - 56f), 40f, 40f, outerBorderPaint)

        val innerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = borderColor
            this.style = Paint.Style.STROKE
            this.strokeWidth = 1.5f
            this.alpha = 90
        }
        canvas.drawRoundRect(RectF(74f, 74f, width - 74f, height - 74f), 32f, 32f, innerBorderPaint)

        val arefTypeface = ResourcesCompat.getFont(context, R.font.aref_ruqaa) ?: Typeface.SERIF
        val amiriTypeface = ResourcesCompat.getFont(context, R.font.amiri) ?: Typeface.SERIF
        val cairoTypeface = ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.SANS_SERIF

        // Topic pill at top
        val topicPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = cairoTypeface
            textSize = 32f
            color = accentColor
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("✦  ${quote.topic}  ✦", width / 2f, 168f, topicPaint)

        // Decorative quotation mark
        val markPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = amiriTypeface
            textSize = 120f
            color = borderColor
            alpha = 160
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("«", width / 2f, 290f, markPaint)

        // Main quote text centered using StaticLayout
        val quoteFontSize = when {
            quote.text.length > 220 -> 42f
            quote.text.length > 130 -> 48f
            else -> 56f
        }
        val quotePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = amiriTypeface
            textSize = quoteFontSize
            color = textColor
        }
        val maxTextWidth = width - 220
        val quoteLayout = StaticLayout.Builder
            .obtain("« ${quote.text} »", 0, quote.text.length + 4, quotePaint, maxTextWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(16f, 1.28f)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()

        val quoteAreaCenterY = 620f
        val quoteStartY = (quoteAreaCenterY - quoteLayout.height / 2f).coerceAtLeast(310f)
        canvas.save()
        canvas.translate(110f, quoteStartY)
        quoteLayout.draw(canvas)
        canvas.restore()

        // Divider line above author
        val lineY = (quoteStartY + quoteLayout.height + 64f).coerceAtMost(980f)
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = borderColor
            strokeWidth = 2.5f
            alpha = 160
        }
        canvas.drawLine(width / 2f - 110f, lineY, width / 2f + 110f, lineY, dividerPaint)

        // Author name
        val authorPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = cairoTypeface
            textSize = 36f
            color = accentColor
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("— ${quote.authorName}", width / 2f, lineY + 62f, authorPaint)

        // Circular Athar pen & butterfly logo emblem
        val logoRadius = 34f
        val logoCenterX = width / 2f
        val logoCenterY = height - 218f
        runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.img_athar_logo)
        }.getOrNull()?.let { rawLogo ->
            val diameter = (logoRadius * 2f).toInt()
            val scaledLogo = Bitmap.createScaledBitmap(rawLogo, diameter, diameter, true)
            val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = BitmapShader(scaledLogo, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply {
                    val m = Matrix()
                    m.setTranslate(logoCenterX - logoRadius, logoCenterY - logoRadius)
                    setLocalMatrix(m)
                }
            }
            canvas.drawCircle(logoCenterX, logoCenterY, logoRadius, logoPaint)
            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = borderColor
                this.style = Paint.Style.STROKE
                this.strokeWidth = 2.5f
            }
            canvas.drawCircle(logoCenterX, logoCenterY, logoRadius + 2f, ringPaint)
        }

        // Athar logo watermark at bottom
        val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = arefTypeface
            textSize = 62f
            color = accentColor
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("أثر", width / 2f, height - 134f, brandPaint)

        val taglinePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = cairoTypeface
            textSize = 24f
            color = secondaryTextColor
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("منصة الاقتباسات العربية الراقية", width / 2f, height - 92f, taglinePaint)

        bitmap
    }

    suspend fun saveQuoteBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        quoteId: String
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val fileName = "athar_quote_${quoteId.take(10)}_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Athar")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext Result.failure(IllegalStateException("تعذر إنشاء ملف الصورة"))
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                Result.success(uri)
            } else {
                // On API < 29, save to cache via FileProvider for zero-permission sharing
                val shareUri = saveBitmapToShareCache(context, bitmap, fileName)
                Result.success(shareUri)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun shareQuoteCardImage(
        context: Context,
        bitmap: Bitmap,
        quote: Quote
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val fileName = "athar_share_${quote.id.take(10)}.png"
            val uri = saveBitmapToShareCache(context, bitmap, fileName)
            withContext(Dispatchers.Main) {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "«${quote.text}»\n— ${quote.authorName}\nعبر تطبيق أثر\nhttps://athar.app/quote/${quote.id}"
                    )
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(shareIntent, "مشاركة بطاقة الاقتباس")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun saveBitmapToShareCache(context: Context, bitmap: Bitmap, fileName: String): Uri {
        val dir = File(context.cacheDir, "quote_cards").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private data class CardColors(
        val bgTop: Int,
        val bgBottom: Int,
        val accent: Int,
        val text: Int,
        val secondary: Int,
        val border: Int
    )
}
