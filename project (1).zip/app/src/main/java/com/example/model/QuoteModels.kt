package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

object AtharConstants {
    const val OWNER_EMAIL = "khaledhouatmi17@gmail.com"
    val TOPICS = listOf("حكمة", "حب", "نجاح", "صبر", "أدب", "أمل", "حياة")
    val REPORT_REASONS = listOf(
        "محتوى مسيء أو غير لائق",
        "اقتباس غير صحيح أو منسوب خطأً",
        "محتوى مكرر أو إعلاني",
        "سبب آخر"
    )
}

@IgnoreExtraProperties
data class Quote(
    @DocumentId val id: String = "",
    val text: String = "",
    val authorName: String = "",
    val topic: String = "حكمة",
    val status: String = "approved", // approved | pending | rejected
    val isOwnerQuote: Boolean = false,
    val isKnownAuthor: Boolean = false,
    val isVerified: Boolean = false,
    val authorImageUrl: String = "",
    val sourceUrl: String = "",
    val submittedByUid: String = "",
    val submittedByName: String = "",
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val isVerifiedKnownAuthor: Boolean
        get() = isKnownAuthor && isVerified && sourceUrl.isNotBlank()
}

@IgnoreExtraProperties
data class QuoteComment(
    @DocumentId val id: String = "",
    val quoteId: String = "",
    val quoteStatus: String = "approved",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val text: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ReportItem(
    @DocumentId val id: String = "",
    val targetType: String = "quote", // quote | comment
    val quoteId: String = "",
    val commentId: String = "",
    val targetPreview: String = "",
    val reason: String = "",
    val reporterUid: String = "",
    val reporterName: String = "",
    val status: String = "open", // open | resolved
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val darkMode: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserFavorite(
    @DocumentId val id: String = "",
    val quoteId: String = "",
    val userId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
